"""Streamlit dashboard: risk-tier segmentation of migrant-worker health records.
Run:  streamlit run app.py
"""
import time

import joblib
import pandas as pd
import streamlit as st

from common import FEATURES, score_workers
from generate_data import HOUSING, OCC, generate

st.set_page_config(page_title="Migrant Worker Risk Tiers", page_icon="🩺", layout="wide")
TIER_COLOR = {"Low": "#2a9d8f", "Medium": "#e9c46a", "High": "#e76f51",
              "Moderate": "#e9c46a", "Critical": "#9b2226"}


@st.cache_resource
def load_bundle():
    return joblib.load("models/bundle.joblib")


@st.cache_data
def load_csv(path):
    return pd.read_csv(path)


try:
    bundle = load_bundle()
except FileNotFoundError:
    st.error("Model not found. Run `python generate_data.py` then `python train.py` first.")
    st.stop()

NAMES = bundle["tier_names"]
st.title("🩺 Migrant Worker Health: Risk-Tier Segmentation (k-Means)")
st.caption("Standardize health-record features → k-Means risk tiers → validate vs disease incidence → targeted outreach")

tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "🧍 Score one worker", "📁 Batch upload", "📡 Live monitor"])

# ------------------------------------------------------------------ dashboard
with tab1:
    sc = load_csv("outputs/workers_scored.csv")
    c = st.columns(len(NAMES))
    for col, name in zip(c, NAMES):
        n = (sc.risk_tier == name).sum()
        col.metric(f"{name} risk", f"{n:,}", f"{100 * n / len(sc):.1f}% of workers")

    st.subheader("Validation: disease incidence by tier (%)")
    inc = load_csv("outputs/incidence_by_tier.csv").set_index("risk_tier")
    st.dataframe(inc.style.format("{:.1f}").background_gradient(cmap="Reds", axis=0), use_container_width=True)

    a, b = st.columns(2)
    a.image("outputs/fig_incidence_by_tier.png", caption="Incidence rises from Low to High tier")
    b.image("outputs/fig_pca_tiers.png", caption="Tiers in 2-D PCA space")
    a.image("outputs/fig_k_selection.png", caption="Choosing k: elbow + validity indices")
    b.image("outputs/fig_centroid_heatmap.png", caption="What defines each tier")

    st.subheader("Tier profiles (average values)")
    st.dataframe(load_csv("outputs/tier_profile.csv"), use_container_width=True)
    st.subheader("Baseline comparison")
    st.dataframe(load_csv("outputs/baseline_comparison.csv"), use_container_width=True)

    st.subheader("🎯 Priority outreach list (highest-risk tier)")
    top = sc[sc.tier_rank == bundle["k"] - 1].sort_values("risk_index", ascending=False)
    st.dataframe(top[["worker_id", "risk_tier", "risk_index", "top_risk_drivers", "occupation",
                      "housing", "work_state"]].head(200), use_container_width=True)
    st.download_button("Download full high-risk list (CSV)", top.to_csv(index=False), "outreach_list.csv")

# --------------------------------------------------------------- single worker
with tab2:
    st.subheader("Enter a worker's screening record")
    c1, c2, c3 = st.columns(3)
    age = c1.number_input("Age", 18, 70, 35)
    bmi = c1.number_input("BMI", 12.0, 45.0, 24.0)
    sbp = c1.number_input("Systolic BP", 80, 220, 125)
    dbp = c1.number_input("Diastolic BP", 40, 140, 80)
    hb = c2.number_input("Hemoglobin (g/dL)", 5.0, 18.0, 12.5)
    glu = c2.number_input("Glucose (mg/dL)", 50, 400, 100)
    spo2 = c2.number_input("SpO2 (%)", 75, 100, 97)
    yrs = c2.number_input("Years in current job", 0.0, 40.0, 4.0)
    occ = c3.selectbox("Occupation", OCC)
    house = c3.selectbox("Housing", HOUSING)
    dust = c3.checkbox("Dust exposure")
    chem = c3.checkbox("Chemical exposure")
    visits = c1.number_input("Clinic visits (12 months)", 0, 30, 2)
    missed = c2.number_input("Missed follow-ups", 0, 20, 1)
    since = c3.number_input("Days since last visit", 0, 1500, 90)

    if st.button("Predict risk tier", type="primary"):
        row = pd.DataFrame([dict(age=age, bmi=bmi, systolic_bp=sbp, diastolic_bp=dbp, hemoglobin=hb,
                                 glucose=glu, spo2=spo2, years_in_job=yrs, dust_exposure=int(dust),
                                 chemical_exposure=int(chem), clinic_visits_12m=visits,
                                 missed_followups=missed, days_since_last_visit=since,
                                 occupation=occ, housing=house)])
        r = score_workers(row, bundle).iloc[0]
        st.markdown(f"### Risk tier: <span style='color:{TIER_COLOR.get(r.risk_tier, '#333')}'>"
                    f"{r.risk_tier}</span>", unsafe_allow_html=True)
        st.progress(int(r.risk_index) / 100, text=f"Risk index {r.risk_index:.0f} / 100")
        st.info(f"Main drivers: {r.top_risk_drivers}")

# ---------------------------------------------------------------- batch upload
with tab3:
    st.subheader("Upload a CSV of screening records")
    st.caption("Required columns: " + ", ".join(FEATURES))
    f = st.file_uploader("CSV file", type="csv")
    if f is not None:
        d = pd.read_csv(f)
        missing = [c for c in FEATURES if c not in d.columns]
        if missing:
            st.error(f"Missing columns: {missing}")
        else:
            res = score_workers(d, bundle)
            st.success(f"Scored {len(res):,} workers")
            st.bar_chart(res.risk_tier.value_counts().reindex(NAMES))
            st.dataframe(res.sort_values("risk_index", ascending=False), use_container_width=True)
            st.download_button("Download results", res.to_csv(index=False), "scored_workers.csv")
    st.download_button("Download sample input file",
                       generate(50, seed=7, with_outcomes=False)[["worker_id"] + FEATURES].to_csv(index=False),
                       "sample_input.csv")

# ---------------------------------------------------------------- live monitor
with tab4:
    st.subheader("Simulated live screening feed")
    st.caption("New records arrive, are standardized and assigned a tier instantly by the trained model.")
    if "live" not in st.session_state:
        st.session_state.live, st.session_state.seed = pd.DataFrame(), 1000
    auto = st.toggle("Auto-stream new screenings (every 2 s)")
    if st.button("➕ Add 10 new screenings") or auto:
        new = generate(10, seed=st.session_state.seed, with_outcomes=False)
        new["worker_id"] = [f"LIVE{st.session_state.seed}-{i}" for i in range(10)]
        st.session_state.seed += 1
        st.session_state.live = pd.concat([score_workers(new, bundle), st.session_state.live]).head(300)
    live = st.session_state.live
    if len(live):
        m = st.columns(len(NAMES))
        for col, name in zip(m, NAMES):
            col.metric(name, int((live.risk_tier == name).sum()))
        alerts = live[live.tier_rank == bundle["k"] - 1]
        st.markdown("**🚨 Newest high-risk alerts**")
        st.dataframe(alerts[["worker_id", "risk_index", "top_risk_drivers", "occupation", "housing"]].head(15),
                     use_container_width=True)
        st.markdown("**All incoming records**")
        st.dataframe(live[["worker_id", "risk_tier", "risk_index", "top_risk_drivers"]].head(50),
                     use_container_width=True)
    if auto:
        time.sleep(2)
        st.rerun()
